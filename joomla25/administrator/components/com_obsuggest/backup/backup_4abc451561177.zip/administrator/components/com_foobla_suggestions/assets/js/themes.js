// JavaScript Document
var ColorDialog = { 	
	prev		: null,
	oldColor	: null,
	newColor	: null,
	storeColor	: null,	
	color		: '#000000',
	onDone		: function(){},
	sliders		: [null, null, null],
	referenceTo	: null,
	referencePro: null,
	updateColor: function(clr){
		this.newColor.style.backgroundColor = clr;
		if($E('#color-transparent').checked)
			this.storeColor.style.backgroundColor = 'transparent';
		else
			this.storeColor.style.backgroundColor = this.newColor.style.backgroundColor;
		if(this.referenceTo!=null)
		{
			this.referenceTo.setStyle(this.referencePro, clr);
		}		
	},
	setTransparent: function(t)
	{
		if(!t) return;
		this.sliders.each(function(el, i){ColorDialog.sliders[i].set(255);})
	},
	done: function()
	{
		if($E('#color-transparent').checked)
			this.storeColor.style.backgroundColor = 'transparent';
		else
			this.storeColor.style.backgroundColor = this.newColor.style.backgroundColor;
		this.color = this.storeColor.style.backgroundColor;
		this.hide();
		this.onDone();
	},
	cancel: function()
	{
		this.storeColor.style.backgroundColor = this.oldColor.style.backgroundColor;
		this.referenceTo.setStyle(this.referencePro, this.oldColor.style.backgroundColor);
		this.hide();
	},
	show: function(el,ref, onDone)
	{		
		this.oldColor = $E('#old-color');//document.getElementById('preview-color')
		this.newColor = $E('#new-color');//document.getElementById('preview-color')
		this.storeColor = document.getElementById(el)
		
		if(typeof(ref)!='undefined')
		{
			this.referenceTo = $E(ref[0]);
			this.referencePro = ref[1];
		}
		this.onDone = (onDone!='undefined') ? onDone : function(){}
		var tmp = this.storeColor.style.backgroundColor;
		var rgb = (tmp=='transparent')?new Array(255,255,255,1):String(tmp.match(/\d+,\s+\d+,\s+\d+/)).split(',');
		
		this.oldColor.style.backgroundColor = tmp;
		$E('#color-transparent').checked = (tmp=='transparent')?true:false;

				
		this.display();
		var index = 0;
		$ES('div.slider').each(
			function(el, i){
				var p = ColorDialog;
				p.sliders[i] = new Slider(el, el.getElement('.knob'), {
					steps: 255,  // Steps from 0 to 255
					wheel: true,
					onChange: function(){
						rgb[i] = this.step;
						p.updateColor(rgb.rgbToHex());
					}

				}).set(parseInt(rgb[i]));				
			}
		);		
	},
	display: function()
	{
		var el = $E('#color-selector');//.setStyle('display', 'block');		
		el.setStyle('top', '300px')//String(parseInt(this.storeColor.getStyle('top'))+12)+'px');
		el.setStyle('left', '400px')//this.storeColor.getStyle('left'));
		el.setStyle('display', 'block');
	},
	hide: function()
	{
		$E('#color-selector').setStyle('display', 'none');		
	}
}


css = {}
//
var ColorTheme = {
	
	init: function()
	{
		
	},
	generateColor: function()
	{
		var rgb = Array(3);
		rgb[0] = String(parseInt(Math.random()*255));
		rgb[1] = String(parseInt(Math.random()*255));
		rgb[2] = String(parseInt(Math.random()*255));
		
		return 'rgb(' + rgb.join(',') + ')'
	}
}
function displayPropertiesStaus(list)
{
	$ES("div.idea-status").each(
		function(el)
		{
			el.style.display = 'none';
		}
	)
	var op = list.options[list.selectedIndex];
	
	
	
	var cur_item = $E('div.box-title div.status').getElementsByTagName('span').item(0)
	if(cur_item!=null)
		cur_item.inject($E('#list-temp-idea-status'))
	
	cur_item = $E('#list-temp-idea-status').getElementsByClassName('status_'+op.value).item(0)
	
	cur_item.inject($E('div.box-title div.status'))
	$E("#idea-status-"+op.value).style.display='block';
	
	var items = $E("#idea-status-"+op.value).getElementsByClassName('box-temp-color')
	for(var i=0; i<items.length;i++)
	{
		var item = items[i]
		var pro = recognize(item.id);
		if(pro[0]!='')
		{
			if($E(pro[0])!=null)
			item.setStyle('background-color', getProperty($E(pro[0]).getStyle(pro[1])))
			//alert(pro[0])
		}
		item.addEvent('click',
			function(evt)
			{
				var pro = recognize(this.id);
				ColorDialog.show(this.id, pro, function(){
					$E(pro[0]).setStyle(pro[1], ColorDialog.color)
				});
			}
		)	
	}
	//$E("#idea-status-"+item).style.backgroundColor='rgb(0,0,0)';
}
function saveSchema(newname)
{
	var items = $ES(".noclass");
	var pros='';
	var item=null;
	var reg = new RegExp(/_/)
	for(var i=0; i<items.length; i++)
	{
		item=items[i];
		var pro_name = item.id.replace(/-/g,'_');
		switch(item.tagName.toLowerCase())
		{
			case 'div':
				if((item.id.indexOf('background')>-1)||(item.id.indexOf('color')>-1))
				{
					var pro = recognize(item.id);
					if(typeof(css[pro[0]])=='undefined') css[pro[0]] = '';
					css[pro[0]]+= '\\t'+pro[1]+":"+item.getStyle('background-color').replace('#','_sharp_')+ ';\\n';
					//pros+= pro[0]+'{;\t'+pro[1]+':'+ item.getStyle('background-color').replace('#','_sharp_')+ ';};';	
				}
				break;
			case 'input':
				break;
			case 'select':
				//pros+=pro_name+'='+item.value+";";	
				//alert(item.id);
				switch(item.id)
				{
					case 'title-font-size':
						//pros+='div.box-idea div.box-title div.title a,'
						//pros+='div.box-idea div.box-title div.title a span{font-size:'+item.value+'};'
						break;
				}
				break;	
			default:
				//alert(item.tagName)	
		}
	}
	pros='';
	for(key in css)
	{
		//alert(css[key])
		pros+=key+"{\\n"+css[key]+"}\\n";
	}
	css = {};
	var url = 'index.php?option=com_foobla_suggestions&controller=themes&task=saveSchema&format=raw&theme=default';
	url+='&schema='+($type(newname)=='string'?newname+'&newname=1':'default');
	url+='&pros='+pros;	
	var req = new Ajax(
		url,
		{
			method:'get',			
			onComplete:function(result)
			{
				//alert(result)
				alert('Color schema has been save!')
			}
		}
	).request();
}


function generateColor()
{
	var rgb = Array(3);
	rgb[0] = String(parseInt(Math.random()*255));
	rgb[1] = String(parseInt(Math.random()*255));
	rgb[2] = String(parseInt(Math.random()*255));
	
	return 'rgb(' + rgb.join(',') + ')'
}
function makeTransparent(id)
{
	var item = document.getElementById(id)
	item.style.backgroundColor = 'transparent';
	item.fireEvent("click",'transparent')	
}
function recognize(info)
{
	var ret = new Array(2);
	var pos = info.indexOf('[');
	ret[0] = info.substr( 0, pos); // elements
	ret[1] = info.substr( pos +1, info.length-pos-2); // property
	return ret;
}
function getProperty(pro, i)
{
	if(typeof(i)=='undefined')
		i=0;
	var arr = pro.split(" ")
	return arr[i] 
}

function init()
{
	var items = $ES(".noclass");
	var item = null;
	for(var i=0; i<items.length; i++)
	{
		item=items[i];
		switch(item.tagName.toLowerCase())
		{
			case 'div':
				if((item.id.indexOf('background')>-1)||(item.id.indexOf('color')>-1))
				{
					var pro = recognize(item.id);
					if(pro[0]!='')
					{
						if($E(pro[0])!=null)
						item.setStyle('background-color', getProperty($E(pro[0]).getStyle(pro[1])))
						//alert(pro[0])
						//alert($E(pro[0]).getStyle(pro[1]))
					}
					item.addEvent('click',
						function(evt)
						{
							var pro = recognize(this.id);
							ColorDialog.show(this.id, pro, function(){
								$E(pro[0]).setStyle(pro[1], ColorDialog.color)
							});
						}
					)	

				}
				break;	
		}
			
	}
	
	
}
function setElementFontSize(id, val)
{
	$E('div.box-idea div.box-title div.title a').setStyle('font-size', val)
}

function saveSchemaAs()
{
	var name = prompt("Name?")
	saveSchema(name)
}   
function changeSchema(name)
{
	var schema = 'schema_'+name+'/'+name+'.css';
	var file = 'http://localhost/joomlatest/components/com_foobla_suggestions/themes/default/'+schema;
	var files_exists = document.getElementsByTagName("head")[0].getElementsByTagName('LINK')
	for(var i=0;i<files_exists.length;i++)
	{
		if(files_exists[i].href.indexOf(schema)>-1)
		{
			document.getElementsByTagName("head")[0].removeChild(files_exists[i])
			i--
			//alert("exists")
		}
	}
	loadFile(file)
}      
function loadFile(filename, filetype){
	if(typeof filetype=='undefined')
		filetype = filename.substr(filename.lastIndexOf('.')+1, 3)
	//alert(filetype)
	if (filetype=="js"){ //if filename is a external JavaScript file
		var fileref=document.createElement('script')
		fileref.setAttribute("type","text/javascript")
		fileref.setAttribute("src", filename)
	}
	else if (filetype=="css"){ //if filename is an external CSS file
		var fileref=document.createElement("link")
		fileref.setAttribute("rel", "stylesheet")
		fileref.setAttribute("type", "text/css")
		fileref.setAttribute("href", filename)
	}
	if (typeof fileref!="undefined")
	{
		document.getElementsByTagName("head")[0].appendChild(fileref)
		setTimeout('init()',3000)
	}
}

window.addEvent('domready',
	function()
	{
		var list = document.getElementById('list-idea-status')
		var oldItem = list.selectedIndex;
		for(var i=0;i<list.options.length;i++)
		{
			list.selectedIndex = i
			displayPropertiesStaus(list)
		}
		list.selectedIndex = oldItem
		displayPropertiesStaus(list)
		init();	
	}
)