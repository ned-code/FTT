<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Tu Ngoc - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

class ControllerThemes extends JController
{
	public function __construct()
	{
		parent::__construct();
	}
	public function display()
	{
		$view = &$this->getView('themes');
		$model = &$this->getModel('themes');
		
		$view->setModel(&$model);
		$view->display();
	}
	function getListSchemas()
	{
		$view = &$this->getView('themes');
		$model = &$this->getModel('themes');
		
		$view->setModel(&$model);
		$view->displayListSchemas();
	}
	function save()
	{
		$view = &$this->getView('themes');
		$model = &$this->getModel('themes');
		
		$model->saveConfig();
		
		$view->setModel(&$model);
		$view->display();
	}
	function saveSchema()
	{
		//$view = &$this->getView('themes');
		$model = &$this->getModel('themes');
		$theme = JRequest::getString('theme', 'default');
		$schema = JRequest::getString('schema', 'default');
		$pros = JRequest::getString('pros','');
		
		$pros = str_replace('_sharp_', "#",$pros);
		
		$model->saveSchema($theme, $schema, $pros);
		echo $pros;
		
		//$view->setModel(&$model);
		//$view->display();
	}
} // end class
?>