<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Tu Ngoc - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
define('FOLDER_THEMES', 'themes');
define('PATH_THEMES', str_replace(DS."administrator","",JPATH_COMPONENT.DS.'themes'));
define('URL_THEMES', str_replace('/administrator','',JURI::base())."/components/".$option.'/themes');

class Themes{
	function __construct(){
	
	}
	function setTheme()
	{
		$document = & JFactory::getDocument();
	
		$info = $this->getThemesActive();
		$paths = $this->themeToPath($info);
		
		if(count($paths))
		{
			foreach ($paths as $path)
			{
				if($path['ext']=='js')
					$document->addScript($path['name']);
				elseif($path['ext']=='css')	
				{
					$document->addStyleSheet($path['name']);
				}
			}
		}
		$document->addStyleSheet(URL_THEMES."/".$info['theme_name']."/".'schema_'.$info['schema_name']."/".$info['schema_name'].".css");
	}
	public function getListThemes()
	{
		$path_themes = str_replace(DS."administrator","",JPATH_COMPONENT.DS.'themes'.DS);
		$themes = JFolder::folders($path_themes);
		$ret	= null;
		foreach ($themes as $theme)
		{
			if($theme=='default')
			{
				$ret[] = array('name'=>$theme, 'url'=>URL_THEMES, 'dir'=>PATH_THEMES);
				break;
			}
		}
		foreach ($themes as $theme)
		{
			if($theme!='theme_default')
				$ret[] = array('name'=>$theme, 'url'=>URL_THEMES, 'dir'=>PATH_THEMES);
		}
		return $ret;
	}
	public function getListSchemas($theme_name)
	{
		
		$themes = $this->getListThemes();
	
		$ret = null;
		foreach ($themes as $theme)
		{
			if($theme['name'] == $theme_name)
			{
				$files = JFolder::folders($theme['dir'] .DS. $theme_name);
				//echo "[".$theme['dir'] .DS. $theme_name."]";
				
				if(count($files)>0)
				{
					foreach ($files as $file)
					{
						if(strpos($file, 'schema_')===false)
							continue;
						if($file=='schema_default')
						{
							$ret[] = array(	'name'=>str_replace('schema_','',$file), 
											'url'=>$theme['url']."/".$theme_name,
											'dir'=>$theme['dir'].'/'.$theme_name
										  );
							break;										  
						}
					}
					foreach ($files as $file)
					{
						if(strpos($file, 'schema_')===false)
							continue;
						if($file!='schema_default')
						{
							$ret[] = array(	'name'=>str_replace('schema_','',$file), 
											'url'=>$theme['url']."/".$theme_name,
											'dir'=>$theme['dir'].'/'.$theme_name
										  );
						}
					}
				}
				break;
			}
		}
		return $ret;
	}
	function getThemesActive()
	{
		$path_inf = str_replace(DS."administrator","",JPATH_COMPONENT.DS.'themes'.DS.'config.inf');
		
		$content = JFile::read($path_inf);
		$infos = explode("\n",$content);
		$ret = array();
		foreach ($infos as $info)
		{
			$info = explode("=", $info);
			$ret[trim($info[0])] = trim($info[1]);
		}
		return $ret;
	}
	function themeToPath($info, $type = 'all')
	{
		$path_theme = PATH_THEMES.DS.$info['theme_name'];
		$path_schema = $path_theme .DS. 'schema_'.$info['schema_name'];
		$url_theme = URL_THEMES."/".$info['theme_name']."/";
		$url_schema = $url_theme."/".'schema_'.$info['schema_name']."/";
		
		$files = JFolder::files($path_theme);
		$ret = array();
		$ext = '';
		if(is_array($type))
		{
			foreach ($files as $file)
			{		
				$ext = JFile::getExt($file);	
				if(in_array($ext,$type)	)	
				{
					$ret[] = array('name'=>$url_theme.$file, 'ext'=>$ext);
				}
			}
		}
		else 
		{			
			foreach ($files as $file)
			{
				$ext = JFile::getExt($file);	
				if($type=='all' || $type==$ext)		
				{
					$ret[] = array('name'=>$url_theme.$file, 'ext'=>$ext);
				}
			}
		}
		return $ret;
	}
	function getHTML($theme, $schema)
	{
		$path = PATH_THEMES.DS.$theme.DS.'html.php';
		$content = '';
		ob_start();
		include_once($path);
		$content = ob_get_contents();
		ob_end_clean();
		return $content;
	}
	function saveSchema($theme, $schema, $pros)
	{
		$path = PATH_THEMES.DS.$theme.DS.'schema_'.$schema.DS.$schema.'.css';
		$pros = str_replace('\\n', "\n", $pros);
		$pros = str_replace('\\t', "\t", $pros);
		$pros = "/* schema $schema */\n" . $pros;
		JFile::write($path, $pros);

	}
	function loadSchema($theme, $schema)
	{
		$path = PATH_THEMES.DS.$theme.DS.'schema_'.$schema.DS.$schema.'.css';
		if(!JFile::exists($path))
			return ;
		$content = JFile::read($path);
		$content = explode("\n", $content);
		$ret = null;
		if(count($content))
		{
			$ret = array();
			foreach ($content as $pro)
			{
				$pro_ = explode('=', $pro);
				$ret[trim($pro_[0])] = trim($pro_[1]);
			}
		}
		return $ret;
	}
}
?>