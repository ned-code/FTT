<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Tu Ngoc - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
define('FOLDER_THEMES', 'themes');
define('PATH_THEMES', str_replace(DS."administrator","",JPATH_COMPONENT.DS.'themes'));
class ModelThemes extends JModel {
	
	function __construct() {
		parent::__construct();
	}
	function getListThemes()
	{
		return Themes::getListThemes();
	}
	function getListSchemas($theme)
	{
		$themehelper = new Themes();
		return $themehelper->getListSchemas($theme);
	}
	function getThemesActive()
	{
		$themehelper = new Themes();
		return $themehelper->getThemesActive();
	}
	function saveConfig()
	{
		$theme = JRequest::getString('themes_list', 'default');
		$schema = JRequest::getString('schemas_list', 'default');
		
		$config = 'theme_name=' . $theme . "\n";
		$config .= 'schema_name=' . $schema;
		
		JFile::write(PATH_THEMES . DS . 'config.inf', $config);
	}
	function getHTML($theme, $schema){
		$themehelper = new Themes();
		return $themehelper->getHTML($theme, $schema);
	}
	function saveSchema($theme, $schema, $pros)
	{
		$themehelper = new Themes();
		return $themehelper->saveSchema($theme, $schema, $pros);
	}
	function loadSchema($theme, $schema)
	{
		$themehelper = new Themes();
		return $themehelper->loadSchema($theme, $schema);
	}
	function getListStatus()
	{
		$db = &JFactory::getDBO();
		$query = "
			SELECT title, id 
			FROM #__foobla_uv_status
			WHERE parent_id<>-1
		";
		$db->setQuery($query);
		$result = $db->loadObjectList();
		return $result;
	}
}
?>