<?php
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Tu Ngoc - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// ensure a valid entry point
defined('_JEXEC') or die('Restricted Access');
JHTML::_('behavior.mootools');
JHTML::_('behavior.tooltip');

$document = & Jfactory::getDocument();
$document->addStyleSheet(JURI::base() ."components/$option/assets/css/themes.css");
$document->addScript(JURI::base() ."components/$option/assets/js/themes.js");

$pane = JPane::getInstance('Tabs');
?>


<script>
function get_schema(theme)
{
	var url = 'index.php?option=com_foobla_suggestions&controller=themes&task=getListSchemas&format=raw&theme='+theme;
	var req = new Ajax(
		url,
		{
			method:'get',
			onComplete:function(result)
			{
				document.getElementById('schema_list').innerHTML = result
			}
		}
	).request();
}
</script>
<form name="adminForm" id="adminForm" action="index.php?option=com_foobla_suggestions&controller=themes" method="POST">
<div>
<?
echo $pane->startPane('themes');
echo $pane->startPanel('Change Themes','asd');
?>
	<div class="theme-list">
		<?=JText::_("Current theme : default")?>
        <!--
		<select onchange="get_schema(this.value)" name="themes_list">
    <?
    	
    if(count($this->themes))
    {
    	foreach ($this->themes as $theme)
    	{
    		
    		if($this->theme_active['theme_name'] == $theme['name'])
    		{
    		?>
    			<option value="<?=$theme['name']?>" selected="selected">
    			<? echo $theme['name']=='default'?'--':'';?><?=$theme['name']?>
    			<? echo $theme['name']=='default'?'--':'';?>
    			</option>
    		<?
    		}
    		else 
    		{
    		?><option value="<?=$theme['name']?>">
    		<? echo $theme['name']=='default'?'--':'';?>
    		<?=$theme['name']?>
    		<? echo $theme['name']=='default'?'--':'';?>
    		</option><?
    		}
    	}
    }
    ?>
    	</select>
        -->
    </div>
    <hr size="1" style="color:#CCCCCC;">
    <div>
    	<div class="theme-view">
    	Theme preview
    	<?
    		echo $this->html;
    	?>
    		<div style="clear:both;">
	    		
	    	</div>
    	</div>
        
        <div class="schema-list" style="border:0px solid red;">
        	<div id="schema_title">Current schema color : default</div>
        	<div id="schema_list">
            	<!--
        		<select name="schemas_list" onchange="changeSchema(this.value)">
        		<?
        		if(count($this->schemas))
        		{
        			foreach ($this->schemas as $schema) {
        				if($schema['name']==$this->theme_active['schema_name'])
        				{
        				?>
        				<option value="<?=$schema['name']?>" selected="selected">
        				<? echo $schema['name']=='default'?'--':'';?>
        				<?=$schema['name']?>
        				<? echo $schema['name']=='default'?'--':'';?>
        				</option>
        				<?
        				}else{
        				?>
        				<option value="<?=$schema['name']?>">
        				<? echo $schema['name']=='default'?'--':'';?>
        				<?=$schema['name']?>
        				<? echo $schema['name']=='default'?'--':'';?>
        				</option>
        				<?
        				}
        			}
        		}
        		?>
        		</select>
                -->
        	</div>
            <div style="clear:both;"></div>
            <div style="float:left;width:200px;">
            	<fieldset>
                	<legend>Idea</legend>
                    <div>
                    	<table cellpadding="3" width="100%">
                        <!--
                        	<tr>
                            	<td>Border size</td>
                                <td>
                                	
                                </td>
                            </tr>
                        	<tr>
                           --> 
                            	<td width="50">Border Color</td>
                                <td align="right">
                                	<div id="div.box-idea[border-color]" class="noclass box-temp-color" ></div>
                                    </td>
                            </tr>
                            <tr>   
                                <td>Back-ground</td>
                                <td align="right">
                                	<div id="div.box-idea[background-color]" class="noclass box-temp-color"></div>                                    
                                </td>
							</tr>
                            
						</table>                            
                    </div>
                </fieldset>
        		<fieldset>
                	<legend>Title</legend>
                    <div>
                    	<table cellpadding="3" width="100%">
                        	<tr style="background:#F0F0F0"><td colspan="2">Title</td></tr>
                        	<tr>
                            	<td width="50">Color</td>
                                <td align="right">
                                	<div id="div.box-idea div.box-title div.title a[color]" class="noclass box-temp-color"></div>                                    
                                    </td>
                            </tr>
                            <tr>   
                                <td>Back-ground</td>
                                <td align="right">
                                	<div id="div.box-idea div.box-title div.title a[background-color]" class="noclass box-temp-color"></div>
                                </td>
							</tr>
                            <!--
                            <tr>                                
                                <td>Font-size</td>
                                <td align="right"><div class="noclass">
                                	<select class="noclass" id="title-font-size" onchange="setElementFontSize('',this.value)">
                                    <?
                                    	echo $this->listFontSize();
									?>
                                    </select>
                                </div></td>
                            </tr>-->
                            <tr style="background:#F0F0F0">
                            	<td width="50">Status</td>
                            	<td align="right">
                                	<select class="noclass" id="list-idea-status" onchange="displayPropertiesStaus(this)">
                                    	<option value="">Start / Set Close</option>
                                    <?
									foreach ($this->list_status as $status)
									{
										$class_name = strtolower(str_replace(" ","_",$status->title));
									?>                                    	                                        
                                        <option value="<?=$class_name?>"><?=$status->title?></option>
                                    <?
                                    }
									?>
                                    </select>  
                                    <div id="list-temp-idea-status" style="display:none;">
                                    	<span style="padding:0px 5px;" class="status_">
                                            Status / Set Close
                                        </span>
                                    <?
									foreach ($this->list_status as $status)
									{
										$class_name = strtolower(str_replace(" ","_",$status->title));
									?>                                    	                                        
                                    	<span style="padding:0px 5px;" class="status_<?=$class_name?>">
                                            <?=$status->title?>
                                        </span>
                                    <?
                                    }
									?>
                                    </div>                                 
                                </td>
                            </tr>
                            <tr>
                            	<td colspan="2">
                                <div id="idea-status-" class="idea-status">
                                	<table width="100%">
                                        <tr>
                                            <td width="50">Color</td>
                                            <td align="right"><div class="noclass box-temp-color" id="div.status span.status_[color]" style="background:#FF0000;"></div></td>
                                        </tr>
                                        <tr>                                
                                            <td>Back-ground</td>
                                            <td align="right"><div class="noclass box-temp-color" id="div.status span.status_[background-color]" style="background:#ffffff;"></div></td>
                                        </tr>
                                        <!--
                                        <tr>                                
                                            <td>Font-size</td>
                                            <td align="right"><div class="noclass" id="idea-status-0-font-size">24px</div></td>
                                        </tr>-->
                               		</table>
								</div>
                            	<?
                            	foreach ($this->list_status as $status)									
                            	{
									$class_name = strtolower(str_replace(" ","_",$status->title));
                            	?>
                                <div id="idea-status-<?=$class_name?>" class="idea-status">
                                	<table width="100%">
                                        <tr>
                                            <td width="50">Color</td>
                                            <td align="right"><div class="noclass box-temp-color" id="div.status span.status_<?=$class_name?>[color]"></div></td>
                                        </tr>
                                        <tr>                                
                                            <td>Back-ground</td>
                                            <td align="right"><div class="noclass box-temp-color" id="div.status span.status_<?=$class_name?>[background-color]"></div></td>
                                        </tr>
                                        <!--
                                        <tr>                                
                                            <td>Font-size</td>
                                            <td align="right"><div class="noclass" id="idea-status-<?=$status->id?>-font-size">24px</div></td>
                                        </tr>
                                        -->
                               		</table>
								</div>
								<?
                            	}
								?>  
                                                               
                                </td>                                
							</tr>
                        </table>
                    </div>
                </fieldset>
            </div>
            <div style="float:right;width:200px;">
            	<!--
            	<fieldset>
                	<legend>User - Date created</legend>
                    <div>
                    	<table width="100%">
                        	<tr>
                            	<td width="50">Title color</td>
                                <td>sadasd</td>
                            </tr>
                        </table>
                    </div>
                </fieldset>-->
                <fieldset>
                	<legend>Content</legend>
                    <div>
                    	<table width="100%">
                        	<tr>
                            	<td width="50">Color</td>
                                <td align="right">
                                	<div class="noclass box-temp-color" id="div.box-idea div.box-idea-content div.box-content[color]"></div>
                                    </td>
							</tr>
                            <tr>                                
                                <td>Back-ground</td>
                                <td align="right">
                                	<div class="noclass box-temp-color" id="div.box-idea div.box-idea-content div.box-content[background-color]"></div>
								</td>
							</tr>
                            <!--
                            <tr>                                
                                <td>Font-size</td>
                                <td align="right"><div class="noclass" id="idea-content-font-size">24px</div></td>
							</tr>
                            <tr>                                
                                <td>Position</td>
                                <td align="right"><select class="noclass" id="idea-content-position"><option>Left</option><option>Right</option></select></td>
                            </tr>
                            <tr>                                
                                <td>Text-align</td>
                                <td align="right"><select class="noclass" id="idea-content-text-align"><option>Left</option><option>Justify</option><option>Right</option></select></td>
                            </tr>
                            -->
                        </table>
                    </div>
                </fieldset>
                <!--
                <fieldset>
                	<legend>Admin response</legend>
                    <div>
                    	<table>
                        	<tr>
                            	<td>Title color</td>
                                <td>sadasd</td>
                            </tr>
                        </table>
                    </div>
                </fieldset>
                <fieldset>
                	<legend>Comments</legend>
                    <div>
                    	<table>
                        	<tr>
                            	<td>Title color</td>
                                <td>sadasd</td>
                            </tr>
                        </table>
                    </div>
                </fieldset>
                <fieldset>
                	<legend>User action</legend>
                    <div>
                    	<table>
                        	<tr>
                            	<td>Title color</td>
                                <td>sadasd</td>
                            </tr>
                        </table>
                    </div>
                </fieldset>-->
            </div>
        	<div style="clear:both;">
	    		<input type="button" value="Save" onclick="saveSchema()">
	    		<!--<input type="button" value="Save As..." onclick="saveSchemaAs()">-->
	    	</div>
        </div>
        <div style="clear:both;"></div>
    </div>
<?
echo $pane->endPanel();
echo $pane->endPane();	
?>
	
</div>
<style>

</style>
<?

?>
<div id="color-selector" style="border:1px solid #999999;padding:3px;display:none;width:260px;position:absolute;background:#ffffff;">
	<div style="float:left;width:200px;margin-right:5px;">
    <div id="red" class="slider advanced">
        <div class="knob">
        </div>
    </div>
    <div id="green" class="slider advanced">
        <div class="knob">
        </div>
    </div>
    <div id="blue" class="slider advanced">
        <div class="knob">
        </div>
    </div>
    </div>
   	<div id="preview-color" style="width:40px;height:40px;border:1px solid #999999;background:#cccccc;float:right;margin-top:5px;">
    	<div id="old-color" style="height:20px;width:40px;"></div>
    	<div id="new-color" style="height:20px;width:40px;"></div>        
    </div>
    <div style="clear:both;">    	
        <input type="checkbox" onclick="ColorDialog.setTransparent(this.checked)" id="color-transparent" /> Transparent color
        <input type="button" value="Ok" onclick="ColorDialog.done();" />
        <input type="button" value="Cancel" onclick="ColorDialog.cancel();" />
	</div>
</div>    

<input type="hidden" id="task" name="task" value="" />
</form>