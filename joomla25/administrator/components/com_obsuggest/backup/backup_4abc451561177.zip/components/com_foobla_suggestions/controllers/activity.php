<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
jimport('joomla.application.component.controller');

class ControllerActivity extends JController {
	function __construct() {
		parent::__construct();
	}
	
	function display() {
		$user_id = &JRequest::getVar('user_id');			
		
		$page = JRequest::getInt("page", 1);
		$model = &$this->getModel('activity');
		$model->setUserId($user_id);
		
		
		$model->limit =  JRequest::getVar('limit',10);
		$model->limitstart = ($page-1) * JRequest::getVar('limit', 10);// JRequest::getVar('limitstart',0,'default','int');
		
		
		//print_r($_GET);
		$view = &$this->getView('activity');		
		$view->setModel($model,true);
		$view->display();
	}
	function displayIdeas()
	{
		//echo "asdasda:";
		//return ;
		$user_id = &JRequest::getVar('user_id');			
		
		$model = &$this->getModel('activity');
		$model->setUserId($user_id);
		
		$page = JRequest::getInt("page", 1);
		
		$model->limit = JRequest::getVar('limit',10);
		$model->limitstart = ($page-1) * JRequest::getVar('limit',10);
		$view = &$this->getView('activity');		
		$view->setModel($model,true);
		$view->displayIdeas();
	}
	function displayComments()
	{
		$user_id = &JRequest::getVar('user_id');			
		
		$model = &$this->getModel('activity');
		$model->setUserId($user_id);
		
		$page = JRequest::getInt("page", 1);
		
		$model->limit = JRequest::getVar('limit',10);
		$model->limitstart = ($page-1) * JRequest::getVar('limit',10);
		
		$view = &$this->getView('activity');		
		$view->setModel($model,true);
		$view->displayComments();
	}
}
?>