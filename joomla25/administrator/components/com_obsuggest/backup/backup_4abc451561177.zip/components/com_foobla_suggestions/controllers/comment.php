<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
require_once(JPATH_COMPONENT.DS."helper".DS."handy.php");
jimport('joomla.application.component.controller');

class ControllerComment extends JController {
	private $user;
	function __construct() {
		parent::__construct();
		$this->setUser();
	}
	function pagingComment()
	{
		
		$model = &$this->getModel('comment');
		//$model->setIdeaId($idea_id);
		$view = $this->getView('comment');
		$view->setModel($model,true);
		$view->setLayout('default_pagination');
		$view->displayPagination();
	}
	function display() {
		$idea_id = &JRequest::getVar('idea_id');
		$input['idea_id'] = $idea_id;
		$model = $this->getModel('comment');
		$model->setIdeaId($idea_id);
		
		$view = $this->getView('comment');		
		$view->setModel($model,true);
		$view->display();
	}
	
	function getList() {
		$idea_id = &JRequest::getVar('idea_id');
		$model = &$this->getModel('comment');
		$model->setIdeaId($idea_id);
		$view = $this->getView('comment');
		$view->setModel($model,true);
		$view->setLayout('default_comment');
		$view->displayList();
	}
	
	function delComment(){
		$idea_id = &JRequest::getVar('idea_id');
		$comment_id = &JRequest::getVar('id');
		
		$model = &$this->getModel('comment');
		$model->setIdeaId($idea_id);
		$model->setCommentId($comment_id);
		$model->delComment();
		$view = $this->getView('comment');
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->displayComments();
	}
	function getCountComments()
	{
		$idea_id = & JRequest::getVar('idea_id');
		
		$model = &$this->getModel('comment');
		echo $model->getCountComments($idea_id);
	}
	function UdelComment(){
		$comment_id = &JRequest::getVar('id');
		
		$model = &$this->getModel('comment');
		$model->setCommentId($comment_id);
		$view = $this->getView('comment');
		$view->setModel($model,true);
		//$view->setLayout('default_comment');
		$view->setLayout('default');
		$view->displayUComment();
	}
	
	function editComment() {
		$comment_id = &JRequest::getVar('id');
		
		$model 	= &$this->getModel('comment');
		$model->setCommentId($comment_id);
		$view	= $this->getView('comment');
		$view->setModel($model,true);
		$view->setLayout('default_edit');
		$view->dispeditComment();
	}
	
	function updateComment() {
		$comment_id 		= &JRequest::getVar('id');
		$comment_content 	= &JRequest::getVar('content');
		$input['comment_id'] 		= $comment_id;
		$input['comment_content'] 	= $comment_content;
		
		$model 	= &$this->getModel('comment');
		echo $model->updateComment($input);
		
	}
	
	public function setUser() {
		$this->user = &JFactory::getUser();
		if ($this->user->usertype == "Guest") $this->user->id = 0;
	}
	
	public function addComment() {
		$idea_id = &JRequest::getVar('idea_id');
		$comment = &JRequest::getVar('comment');
		$forum_id  = &JRequest::getVar('forum_id');
				
		$input['idea_id'] = $idea_id;
		$input['user_id'] = $this->user->id;
		$input['forum_id'] = $forum_id;
		$input['comment'] = $comment;
		$input['createdate'] = Handy::getDateTime();
		
		$model = $this->getModel('comment');
		$model->setIdeaId($idea_id);
		$model->addComment($input);
		
		
		$view = $this->getView('comment');	
		//$view->setLayout('default_comment');	
		$view->setModel($model,true);
		//$view->display();
		$view->displayComments();
		//$view->displayList();
	}
	public function displayComments()
	{
		$view = $this->getView('comment');	
		//echo "sssssssssssssssssssssssssssssssssssssssss";
		$model = &$this->getModel("comment")	;
		$view->setModel($model,true);
		//$view->display();
		$view->displayComments();
	}
}

?>
