<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
jimport('joomla.application.component.controller');
require_once (JPATH_COMPONENT.DS.'classes'.DS.'class.output.php');
require_once (JPATH_COMPONENT.DS.'helper'.DS.'forum.php');

class ControllerDefault extends JController {
	function __construct() {
		parent::__construct();
	}
	
	function display() {
		$forum_id	= &JRequest::getVar('forumId');
		if ($forum_id == 0 or !$forum_id){
			$forum_default = Forum::getForumDefault(); 
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		} 
		
		$model = &$this->getModel('default');
		$model->setForumId($forum_id);
		$view = &$this->getView('default');		
		$view->setModel($model,true);
		$view->display();
	}
	
	function getTabs() {
		$forum_id	= &JRequest::getVar('forumId');
		if ($forum_id == 0 or !$forum_id){
			$forum_default = Forum::getForumDefault(); 
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		} 
		$model = &$this->getModel('default');
		$model->setForumId($forum_id);
		
		$view = &$this->getView('default');
		
		$view->setModel($model,true);
		$view->setLayout('default_tabs');
		$view->dispTabs();
	}
	function autoComplete(){
		$key_word	= &JRequest::getVar('key_search'); 
		$input['key_search']	= $key_word;
		$model = $this->getModel('default');
		$model->getAutoComplete($input);
		exit();
	}
	
	function getComment() {
		$idea_id = &JRequest::getVar('idea_id');
		
		$input['idea_id'] = $idea_id;
		
		$model = $this->getModel('comment');
		$model->setIdeaId($idea_id);
		
		$view = $this->getView('default');		
		$view->setModel($model,true);
		$view->dispComment();
	}
	function changePage() {
		global $mainframe;		
		//$mainframe->redirect("index.php?option=com_foobla_suggestions&forumId=".$_POST['forumId']);
		$mainframe->redirect(JRoute::_("index.php?option=com_foobla_suggestions&forumId=".JRequest::getVar('forumId')));
	}
		
}

?>