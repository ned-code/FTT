<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
jimport('joomla.application.component.controller');
require_once (JPATH_COMPONENT.DS.'helper'.DS.'forum.php');

class ControllerIdea extends JController {
	private $user;
	function __construct() {
		parent::__construct();
		$this->setUser();
	}
	
	function display() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$user_id = &JRequest::getVar('user_id');
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$view = &$this->getview('idea');
		$view->setModel($model,true);
		$view->setLayout('default');
		
		$view->display();
	}
	function dispNewForm() {
		$model = &$this->getModel('idea');
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default_new');
		$view->display();
	}
	
	
	
	function addIdea() {
		$title = &JRequest::getVar('title');
		$content = &JRequest::getVar('content');
		$forum_id = &JRequest::getVar('forum_id');
		if (!$forum_id){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		
		$input['title'] = $title;
		$input['forum_id'] = $forum_id;
		$input['content'] = $content;
		$input['user_id'] = $this->user->id;
		$input['createdate'] = $this->getDateTime();
		
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->addIdea($input);
	}
	
	public function setUser() {
		$this->user = JFactory::getUser();	
		/*		
		if (strpos($this->user->usertype,"Guest") !== false) {		
			$this->user->id = 0;
		}	
		*/
		
	}
	function getDateTime() {
		return date("Y-m-d H:i:s");
	}
	function getIdea() {
		$id = &JRequest::getVar('id');
		
		$model = &$this->getModel('idea');
		$model->setId($id);

		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('idea');
		$view->dispIdea();
	}
	
	function ideaWithUserid(){
		$model = &$this->getModel('idea');
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default_ideas');
		$view->dispIdeaWithUserid();
	}
	
	function IdeaWithStatus(){
		$limitstart	= JRequest::getVar('limitstart',0,'','int');
		$limit = JRequest::getVar('limit',10,'','int');
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$status_id = &JRequest::getVar('status_id');
		$model = &$this->getModel('idea');
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		$model->setStatusId($status_id);
		$model->setForumId($forum_id);
		$model->getListIdea();
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispIdeaWithStatus();
	}

	
	function IdeaById() {
		$idea_id  = &JRequest::getVar('id');
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setIdeaId($idea_id);
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default_ideas');
		$view->dispIdeaById();
	}
	
	function IdeaWithStatusCount() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$status_id = &JRequest::getVar('status_id');
		
		$model = &$this->getModel('idea');
		$model->setStatusId($status_id);
		$model->setForumId($forum_id);
		echo $model->getListIdeaCount();
	}
	
	
	function topIdeaCount() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		echo $model->topIdeaCount();
	}
	
	function topIdea(){
		
		$page = JRequest::getVar('page',1,'','int');
		//echo "[";print_r($_GET);
		//echo "]";
		$limitstart = 10 * ($page-1);				
		$limit = JRequest::getVar('limit',10,'','int');
		
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		
		$model = &$this->getModel('idea');
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		$model->setForumId($forum_id);
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispTopIdea();
	}
	
	function hotIdeaCount() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		
		
		echo $model->getHotIdeaCount();
	}
	/*function getHotIdeasCount() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		
		
		echo $model->getHotIdeaCount();
	}
	*/
	function hotIdea(){
		$page = JRequest::getInt("page", 1);
		
		
		$limit = JRequest::getVar('limit',10,'','int');
		
		$limitstart	= ($page-1)*$limit;
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispHotIdea();
	}
	
	
	function newIdea(){
		$page = JRequest::getInt("page", 1);
		
		
		$limit = JRequest::getVar('limit',10,'','int');
		$limitstart					= ($page-1)*$limit;
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
	
		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispNewIdea();
	}
	function newIdeaCount() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		echo $model->getNewIdeasCount();
	}
	
	function editIdea() {
		$id = &JRequest::getVar('id');
		
		$model = &$this->getModel('idea');
		$model->setId($id);

		$view = $this->getView('idea');
		$view->setModel($model,true);
		$view->setLayout('default_edit');
		$view->dispIdea();
	}
	function updateIdea() {
		$id = &JRequest::getVar('id');
		$title = &JRequest::getVar('title');
		$content = &JRequest::getVar('content');
		
		$input['id'] = $id;
		$input['title'] = $title;
		$input['content'] = $content;
		
		$model = &$this->getModel('idea');
		$model->updateIdea($input);
	}
	
	function addResponse() {
		$id = &JRequest::getVar('id');
		$response = &JRequest::getVar('response');
		
		$input['id'] = $id;
		$input['response'] = $response;
		
		$model = &$this->getModel('idea');
		$model->addResponse($input);
	}
	function delIdea() {
		$id = &JRequest::getVar('id');
		
		$input['id'] = $id;
		
		$model = &$this->getModel('idea');
		
		
		$model->delIdea($input);
		
		$model->setIdeaId($id);
		//$comments = $model->countComments($id);
		
		$view = &$this->getView("idea");
		
		$view->setModel($model);
		
		$view->displayCountIdeas();
	}
	function updateIdeaStatus() {
		$id = &JRequest::getVar('id');
		$status_id = &JRequest::getVar('status_id');
		
		$input['id'] = $id;
		$input['status_id'] = $status_id;
		
		$model = &$this->getModel('idea');
		echo $model->updateIdeaStatus($input);
	}
	function search() { 
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$key = &JRequest::getVar('key');
		$input['key'] = $key;
		
		$page = JRequest::getInt("page", 1);
		
		
		$limit = JRequest::getVar('limit',10,'','int');
		
		$limitstart	= ($page-1)*$limit;
		
		
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setKeySearch($key);
		
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		
		$view = &$this->getView('idea');
		
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispSearch();
	}
	function falconSearch()
	{
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$key = &JRequest::getVar('key');
		$input['key'] = $key;
		
		$page = JRequest::getInt("page", 1);
						
		
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setKeySearch($key);
		
		$model->setLimit(0);
				
		$view = &$this->getView('idea');
		
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispSearch('search_result');
	}
	function getCountSearch()
	{
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$key = &JRequest::getVar('key');
		$input['key'] = $key;
		
		$limitstart	= JRequest::getVar('limitstart',0,'','int');
		$limit = JRequest::getVar('limit',10,'','int');
		
		
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setKeySearch($key);
		
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		
		$ideas = $model->getIdeas();
		//print_r($ideas);
		echo $model->total;
	}
	function autoComplete() {
		$forum_id = &JRequest::getVar('forum');
		if (!$forum_id or $forum_id ==0){
			$forum_default = Forum::getForumDefault();
			$forum_id = &JRequest::getVar('id',$forum_default->id);
		}
		$key = &JRequest::getVar('key');
		$input['key'] = $key;
		
		$model = &$this->getModel('idea');
		$model->setForumId($forum_id);
		$model->setKeySearch($key);
		$model->getAutoComplete();
		exit();
	}
	
	function updateVote() {
		$id = JRequest::getVar('id');
		$vote = JRequest::getVar('vote');
		
		$input['id'] = $id;
		$input['vote'] = $vote;
		
		$model = &$this->getModel('idea');						
		echo Number::createNumber($model->updateVote($input));	//???			
	}
	
	/***************/	
	function getSuggest() {
		$key = &JRequest::getVar('key');
		$input['key'] = $key;
		
		$model = &$this->getModel('idea');
		$model->setKeySearch($key);
		$view = &$this->getView('idea');
		
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispSearch();
	}
	/**************/
	
	public function getAllIdeas()
	{
		$limitstart	= JRequest::getVar('limitstart',0,'','int');
		$limit = JRequest::getVar('limit',10,'','int');
		
		
		$model = &$this->getModel('idea');
		
		$model->setLimit($limit);
		$model->setLimitstart($limitstart);
		
		$view = &$this->getView('idea');
		
		$view->setModel($model,true);
		$view->setLayout('default');
		$view->dispSearch();
	}
}

?>