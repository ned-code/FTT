<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Tu Ngoc - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
class Number
{
	function createNumber($num, $padleft = true)
	{
		if($num<0)
			$num = 0;
		if($padleft)
			$num = substr("000" . $num, -3, 3);
		$len = strlen($num)	;
		//echo (($len+1)*3);
		$ret = '<div class="number" style="width:'.(($len)*15).'px;">';
		for ($i = 0; $i<$len; $i++)		
		{
			$digit = substr($num, $i, 1);
			$ret .= '<span class="num'.$digit.'"></span>' . "\n";
		}
		$ret.="</div>";
		return $ret;
	}
}
?>