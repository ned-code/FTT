<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
?>
<?
jimport('joomla.application.component.view');

class ViewActivity extends JView {
	function __construct() {
		parent::__construct();
	}
	
	function display($tmp = null) {
		// status of idea
		$status = $this->get('Status');
		
		// list of ideas
		$ideas = $this->get('Ideas');
		
		// list of comments
		$comments = $this->get('Comments');		
		
		// num of ideas
		$sumideas = $this->get('NumIdeas');
		
		//  num of comments
		$sumcomments = $this->get('NumComments');
		
		// some infomation...
		$output = $this->get('Output');
		
		// is not search
		$search = 0;
		
		// get cuurent page
		$page = JRequest::getInt("page", 1);
		
		// model instance
		$model = &$this->getModel('activity');
		
		$user = $model->getUser($model->user_id);			
		
		if($sumideas>10)
		{
			$pagination = new Paging($sumideas, $page, 10, ("index.php?option=com_foobla_suggestions&controller=activity&task=displayIdeas&format=raw&user_id=" . $model->user_id));		
			$pagination = $pagination->getPagination();
		}
		else 
			$pagination = "";
		
		if($sumcomments>10)	
		{
			$pageComment = new Paging($sumcomments, $page, 10, "index.php?option=com_foobla_suggestions&controller=activity&format=raw&task=displayComments&user_id=" . $model->user_id);		
			$pageComment =  $pageComment->getPagination();
		}
		else $pageComment = "";
		
		// assign some variable
		
		$this->assignRef("pagination", $pagination); // pagination ideas
				
		$this->assignRef("pageComment", $pageComment); // pagination comments
				
		$this->assignRef('status',$status);	
		$this->assignRef('total', $sumideas)	;
		$this->assignRef('user',$user);
		$this->assignRef('ideas',$ideas);
	
		$this->assignRef('comments',$comments);
		$this->assignRef('search',$serch);
		$this->assignRef('sumideas',$sumideas);
		$this->assignRef('sumcomments',$sumcomments);
		
		$this->assignRef('output',$output);
		
		parent::display($tmp);
	}
	
	/**
	 * we use AJAX to call this function and get the content of idea and paging it!
	 *
	 */
	function displayIdeas()
	{
		// idea status
		$status = $this->get('Status');
		
		// list of ideas
		$ideas = $this->get('Ideas');
	
		// num of idea
		$sumideas = $this->get('NumIdeas');

		// some infomation
		$output = $this->get('Output');
		
		// is not search
		$search = 0;
		
		// get current page
		$page = JRequest::getInt("page", 1);
		
		// model instance
		$model = &$this->getModel('activity');
		
		$user = $model->getUser($model->user_id);
		
		// add the path template to search
		$this->_addPath( 'template', JPATH_COMPONENT.DS.'views'.DS. 'idea'.DS.'tmpl' ); 		
		if($sumideas>10)
		{
			$pageIdea = new Paging($sumideas, $page, 10, "index.php?option=com_foobla_suggestions&controller=activity&format=raw&task=displayIdeas&user_id=" . $model->user_id);		
			$pageIdea = $pageIdea->getPagination();
		}else
		{
			$pageIdea = "";
		}						
		// assign some variable
		$this->assignRef("pagination", $pageIdea);
		$this->assignRef('status',$status);	
		$this->assignRef('total', $sumideas)	;
		$this->assignRef('user',$user);
		$this->assignRef('ideas',$ideas);		
		$this->assignRef('search',$serch);
		$this->assignRef('sumideas',$sumideas);		
		$this->assignRef('output',$output);
		
		// only display content of the ideas
		parent::display("ideas");
	}
	
	/**
	 * we use AJAX to call this function and get the content of comment and paging it!
	 *
	 */
	function displayComments($tmp = null) {
		
		// list comments
		$comments = $this->get('Comments');		

		// sum of comments
		$sumcomments = $this->get('NumComments');
		
		// sum infomation
		$output = $this->get('Output');
		
		// not is search
		$search = 0;
		
		$model = &$this->getModel('activity');
		$user = $model->getUser($model->user_id);			
		
		$page = JRequest::getVar("page", 1)	;
		if($sumcomments>10)
		{
			$pageComment = new Paging($sumcomments, $page, 10, "index.php?option=com_foobla_suggestions&controller=activity&format=raw&task=displayComments&user_id=" . $model->user_id);		
			$pageComment =  $pageComment->getPagination();
		}
		else
		{
			$pageComment = "";
		}
		// assign some variables
		$this->assignRef('status',		$status);	
		$this->assignRef('user',		$user);
		$this->assignRef('comments',	$comments);
		$this->assignRef('search',		$serch);
		$this->assignRef('sumcomments',	$sumcomments);	
		$this->assignRef('output',		$output);
		$this->assignRef("pageComment", $pageComment);
		
		$this->_addPath( 'template', JPATH_COMPONENT.DS.'views'.DS. 'comment'.DS.'tmpl' ); 
		$this->loadTemplate("comment");

		// only need content of the comment
		parent::display("comment_activity");
	}
	function getUser($_user_id) {
		$model = $this->getModel('activity');
		return $model->getUser($_user_id);
	}
	public function getUserVoteIdea($_idea_id) {
		$model = $this->getModel('activity');
		$rs = $model->getUserVoteIdea($_idea_id);
		if ($rs != NULL)
			return $rs->vote;
		else return 0;
	}
}
?>
