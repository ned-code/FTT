<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
?>
<script type="text/javascript">
	function delComment(id){
		var agree = confirm("<?=JText::_("Are you sure delete?")?>");
		var controller = document.getElementById('controller').value;
		
		if (agree){
			 if (controller == 'comment'){
				var idea_id = document.getElementById('idea_id').value;
				var url="index.php?option=com_foobla_suggestions&controller=comment&format=raw&task=delComment&id="+id+"&idea_id="+idea_id;
				var req = new Ajax(url,{
					method:'get',
					onComplete:function(result){
						document.getElementById('contentComment').innerHTML = result;
						document.getElementById('comment_count').innerHTML = $$('div.comment-details').length;
					}
				}).request();
			 }else if (controller == 'activity'){
				 //get list comment of userid
				 
				 var url="index.php?option=com_foobla_suggestions&controller=comment&format=raw&task=UdelComment&id="+id; 
				 var req = new Ajax(url,{
						method:'get',
						onComplete:function(result){
							loadPage('index.php?option=com_foobla_suggestions&controller=activity&format=raw&task=displayComments&user_id='+getUserId()+'&page=1')
							//document.getElementById('list_comment').removeChild(document.getElementById('comment_'+id))
							
							var e = document.getElementById('count_comment');
							if(e)
							{
								e.innerHTML = result;
							}
							//document.getElementById('contentComment').innerHTML = result;
						}
				}).request();
			 }
		}
	}  
	function resetComment() {
		document.getElementById('comment').value = "";
		document.getElementById('comment').focus();
	}
	function addComment() {
		var comment  = document.getElementById('comment').value;
		if (comment == ""){
			alert("<?=JText::_("Enter the content for comments. Please!")?>");
		}else{
			var idea_id  = document.getElementById('idea_id').value;
			var forum_id = document.getElementById('forum_id').value;
			
			var url="index.php?option=com_foobla_suggestions&controller=comment&format=raw&task=addComment&idea_id="+idea_id+"&comment="+comment+"&forum_id="+forum_id;
			var req = new Ajax(url,{
				medthod:'get',
				onComplete:function(result){
					document.getElementById('contentComment').innerHTML = result;					
					document.getElementById('comment').value = "";
					
					document.getElementById('comment_count').innerHTML++;
				}
			}).request();
		}
	} 	
</script>


<div id="list_comment" style="width:100%;border:0px dotted #999999;">
<?php
if (count($this->comments)){
	foreach ($this->comments as $comment) { 
		$user = $this->getUser($comment->user_id);
?>
<div class="comment-details" id="comment_<?php echo $comment->id;?>">
	<div class="username">
		<div class="_image">&nbsp;</div>
		<div class="_name" style="text-align:center;"><?php echo $user->username; ?></div>
	</div>
	
	<div class="comment" id="comment_content_<?=$comment->id?>">
		<div class="content"><?php echo $comment->comment; ?></div>
	</div>	
	
<div style="padding-right:10px;">		
	<span class="createdate">
		<div style="float:right;">									
			<?php if (($this->output->permission->delete_comment_a == 1) || (($this->output->permission->delete_comment_o == 1) && ($this->output->user->id == $comment->user_id))) {?>
			<a href="javascript:delComment(<?php echo $comment->id;?>);"><?=JText::_("Delete")?></a>&nbsp;|&nbsp;
			<?php }?>
			<?=JText::_("Create on")?> <?php echo $comment->createdate; ?></div>							
		<?php if (($this->output->permission->edit_comment_a == 1) || (($this->output->permission->edit_comment_o == 1) && ($this->output->user->id == $comment->user_id))) {?>
		<div class="active" id ="edt<?php echo $comment->id;?>" style="float:right;" onClick="onedit(<?php echo $comment->id;?>)" >
				<a href="javascript:void(0);"><?=JText::_("Edit")?></a>&nbsp;|&nbsp; 
				<a id="frm_Edit_<?php echo $comment->id;?>" href="index.php?option=com_foobla_suggestions&controller=comment&task=editComment&id=<?php echo $comment->id;?>&format=raw" rel="{handler: 'iframe',size: {x: 430, y: 280}}"></a>
		</div>
		<?php }?>
	</span>					
</div></div>
<div style="clear:both;border:0px solid red;border-top:1px dotted #CCCCCC;"></div>
<?php }
}?>
</div>
<div>
	<span class="pagination">
		<div id="Pagination3">
		<? 
		if(count($this->comments)) 
			echo $this->pageComment;
		else 
		{
		?>
		<div style="margin:0px 1px 0px 1px;text-align:center;border:1px dotted #999999;background:#ffffcc;">
		<?
			echo JText::_("No comment for this idea.");
		?>			
		</div>
		<?
		}
		?>
		
		</div>
	</span>			
</div>

