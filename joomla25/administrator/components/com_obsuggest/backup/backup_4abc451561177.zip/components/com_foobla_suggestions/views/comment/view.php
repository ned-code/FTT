<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
jimport('joomla.application.component.view');

class ViewComment extends JView {
	function __construct() {
		parent::__construct();
	}
	
	function display($tmp = null) {
		$ideas = $this->get('Idea');
		$status = $this->get('Status');
		$comments = $this->get('Comments');
		$idea_id = $this->get('IdeaId');
		$forum_id	= $this->get('ForumId');
		$output = $this->get('Output');
		$output->permission->delete_idea_a = 0;
		$output->permission->delete_idea_o = 0;
		
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('comments',$comments);
		$this->assignRef('idea_id',$idea_id);
		$this->assignRef('output',$output);
		
		$model = & $this->getModel('comment');
		$count_comment = $model->getCountComments($idea_id);
		
		$this->assignRef('sumcomments', $count_comment);
		
		$search = 0;
		
		$page = JRequest::getInt("page", 1);
		if($count_comment>10)
		{
			$pageComment = new Paging($count_comment, $page,10, JRoute::_("index.php?option=com_foobla_suggestions&controller=comment&format=raw&task=displayComments&idea_id=$idea_id"));
			$pageComment = $pageComment->getPagination();
		}else 
		{
			$pageComment = "";
		}
		$this->assignRef("pageComment", $pageComment);
		$this->assignRef('search',$search);
		parent::display($tmp);
	}
	function displayComments($tmp = null) {
		$idea_id = JRequest::getVar("idea_id");
		
		$model = &$this->getModel('comment');
		$model->setIdeaId($idea_id);
		$comments = $model->getComments();
		$output = $this->get('Output');
		$output->permission->delete_idea_a = 0;
		$output->permission->delete_idea_o = 0;
		$ideas = $this->get('Idea');		
		
		$this->assignRef('comments',$comments);
		$this->assignRef('output',$output);
		
		//print_r($comments);
	
		$count_comment = $model->getCountComments($idea_id);
		$page = JRequest::getInt("page", 1);
		
		if($count_comment>10)
		{
			$pageComment = new Paging($count_comment, $page,10, JRoute::_("index.php?option=com_foobla_suggestions&controller=comment&format=raw&task=displayComments&idea_id=$idea_id"));
			$pageComment = $pageComment->getPagination();
		}
		else 
		{
			$pageComment = "";
		}
		$this->assignRef("pageComment", $pageComment);
			
		parent::display("comment");
	}
	function displayList($tmp = null) {
		$model = &$this->getModel('comment');
		$comments = $model->getComments();
		$output = $this->get('Output');
		$output->permission->delete_idea_a = 0;
		$output->permission->delete_idea_o = 0;
		$ideas = $this->get('Idea');		
		
		$this->assignRef('comments',$comments);
		$this->assignRef('output',$output);
		$this->assignRef('ideas',$ideas);		
		parent::display($tmp);
	}
	
	function displayComment($tmp = null) {
		$model = &$this->getModel('comment');
		$model->delComment();
		$comments = $model->getListComment();
		$output = $this->get('Output');
		$ideas = $this->get('Idea');
		
		$this->assignRef('comments',$comments);
		$this->assignRef('output',$output);
		$this->assignRef('ideas',$ideas);
		parent::display($tmp);
	}
	function displayUComment($tmp = null) {
		$model = &$this->getModel('comment');
		$model->delComment();
		$comments = $model->ListCommentWithUserId();
		$this->assignRef('comments',$comments);
		$output = $this->get('Output');
		
		$count_comment = count($comments);
		$this->assignRef("count_comments", $count_comment);
		$this->assignRef('output',$output);
		parent::display('count_comments');
	}
	
	function dispeditComment($tmp = null) {
		$model = &$this->getModel('comment');
		
		$comments = $model->editComment();
		$this->assignRef('comments',$comments);
		parent::display($tmp);
	}
	
	function getUser($_user_id) {
		$model = $this->getModel('comment');
		return $model->getUser($_user_id);
	}
	public function getUserVoteIdea($_idea_id) {
		$model = $this->getModel('comment');
		$rs = $model->getUserVoteIdea($_idea_id);
		if ($rs != NULL)
			return $rs->vote;
		else return 0;
	}
}
?>
