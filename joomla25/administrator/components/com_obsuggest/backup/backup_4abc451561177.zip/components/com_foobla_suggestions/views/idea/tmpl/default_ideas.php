<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
 * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
?>
<script type="text/javascript">
//setInterval('autoclose()',5000);
function autoclose() {
	closeForm('voteform');
	closeForm('statusform');
	clickVote_s = 0;
	outVote_s =0;
}
function outVote() { 
	if (clickVote_s == '1')
		outVote_s = 1;
	else outVote_s = 0;
}
function clickVote(){
	clickVote_s = 1;
}
</script>
<style type="text/css">

</style>
<script>

</script>
<div id="search_idea">
	<?php if ($this->search == 1) {?>
	<div>
		<? //echo $this->loadTemplate('search'); ?>			
	</div>
	<?php } ?>	
	<div id="listidea" style="border:1px solid #FFFFFF;">
	<?php  
	if(count($this->ideas))	
	{
		$listVote = Idea::getListVotes();

		foreach($this->ideas as $idea) {
			$user = $this->getUser($idea->user_id); 
	?>
		<div class="clear"></div>
		<div id="idea_info_<?=$idea->id?>" class="box-idea">
        	<div class="box-title">
            	<div class="title">
                	<a href="index.php?option=com_foobla_suggestions&controller=comment&idea_id=<?=$idea->id?>"><span id="title<?=$idea->id?>"><?=$idea->title?></span></a>
                </div>
                <div class="status">
                	<span style="padding:0px 5px;" id="status_title_<?=$idea->id?>" class="status_<? echo str_replace(" ", "_",strtolower($idea->status));?>">
						<? echo $idea->status ? $idea->status : "Status / Set Close"; ?></div>
                    </span>
                <div class="clear"></div>
            </div>
            <div class="box-user">
            	<div class="username">
               	<?=JText::_("by")?>
				<?
					if ($user->username != "anonymous") {
				?>
                   	<a href="index.php?option=com_foobla_suggestions&controller=activity&user_id=<?=$idea->user_id?>"><?php echo $user->username;?></a>
                <? 	} else { 
						echo JText::_("anonymous");
					}
				?>
                </div>
                <div class="createdate">
                <?=JText::_("Create on")?> <? echo $idea->createdate; ?>
                </div>
                <div class="clear"></div>
            </div>
            <div class="box-idea-content">
            	<div class="box-vote">
                	<div class="sum" id="sum_vote_<?=$idea->id?>" style="text-align:center;">
						
						<?
                            echo Number::createNumber($idea->votes);
                        ?>                        	
				
                    </div>    
                    <div class="uservote" style="text-align:center;">
                    	<div style="width:55px;height:20px;margin:0 auto;">
						<?php 
						$user_vote = $this->getUserVoteIdea($idea->id);
                        $can_vote = (($this->output->permission->vote_idea_a == 1) || 
									(($this->output->permission->vote_idea_o == 1) && ($this->output->user->id == $idea->user_id))) ;
						?>                          
                            <div style="float:left;width:20px;height:20px;text-align:left;cursor:pointer;" <? if($can_vote){?>onclick="Vote.up('<?=$idea->id?>')"<? }?>>
                            <? if($can_vote){?>
                            	<div id="left_number_<?=$idea->id?>" class="pre-number<? if($user_vote==0) echo " is-min";?>"></div>
                            <? }else{?> 
                            	<div class="pre-number disabled"></div>
                            <? }?>    
                            </div>
                            <div id="user_vote_<?=$idea->id?>" class="number" style="width:15px;height:20px;overflow:hidden;float:left;">
                        	<?
                    		$str = "";
                        	?>
                            	
                            	<?                            	
                   				
								$vote_value = 0;
								$i=0;
								$end_vote = 0;
								foreach ($listVote as $objVote) {
									if($objVote->vote_value!=$user_vote)
									{
										$i++;										
									}
									else 
										$vote_value = $i;
									$end_vote = $objVote->vote_value;	
									$str .= '<span class="num'.$objVote->vote_value.'" >';
									$str .= '<input id="vote_value_'.$idea->id."_".$objVote->vote_value.'" type="hidden" value="'.$objVote->vote_value.'">';
									$str .= '</span>';								
								}
								$str = '<div style="margin-top:-'.($vote_value*20).'px;">' . $str . '</div>';
								echo $str;
								?>                                    
                                
                            </div>
                            <div style="float:left;width:20px;height:20px;text-align:right;cursor:pointer;" <? if($can_vote){ ?>onclick="Vote.down('<?=$idea->id?>')"<? }?>>
                            <? if($can_vote){?> 
                            	<div id="next_number_<?=$idea->id?>" class="next-number<? if($user_vote==$end_vote) echo " is-max";?>"></div>
							<? }else{?>
                            	<div class="next-number disabled"></div>
                            <? }?>    
                            </div>
                        </div>
						<?php // echo Number::createNumber($this->getUserVoteIdea($idea->id), false);?>
      
                    </div>
                </div>
                <div class="box-content" id="idea<?=$idea->id?>">
            	<?
            		$content = htmlspecialchars_decode($idea->content); // convert quote to html tag
            		$content = strip_tags($content); // remove html tag
            		if(JRequest::getString("controller")=='comment')
            		{
            			echo $content;
            		}
            		else {
            			$content = Idea::cutString($content, 100);
            			echo $content['string'];
            		}
            		
            	?>
                </div>
                <div class="clear"></div>
            </div>
            <input type="hidden" name="_cache_rps_content<? echo $idea->id; ?>" id="cache_rps_content<? echo $idea->id; ?>" value="<?php echo $idea->response;?>" />
			<?
			$can_response = (($this->output->permission->response_idea_a == 1) || (($this->output->permission->response_idea_o == 1) && ($this->output->user->id == $idea->user_id)));			
			?>            	
			<?
			if($can_response)
			{
			?>
            <div class="box-response" >
            	<div style="border:1px dotted #CCCCCC;margin:3px 0px;padding:3px;" id="rps<? echo $idea->id; ?>">	
				<?php 
				
				if ($idea->response != NULL ) 
				{ 
				?>		
								
						<div id="rps-title<? echo $idea->id; ?>" style="font-weight: bolder;margin-bottom: 0px;"><?=JText::_("admin response")?></div>
						<div id="rps-content<? echo $idea->id; ?>" class="rps-content"><i><?php echo $idea->response;?></i></div>
				<?php 			
					if ($can_response) 
					{
					?> 
						<div class="small" style="text-align:right;"><a href="javascript:void(0);" onClick="addRepose('rps<?php echo $idea->id; ?>')">- <?=JText::_("edit")?></a></div>
					<? 
					}
					?>
					
				<?php
				} else {
				?>
					<div style="text-align: right;" >
				<?php 
				if ($can_response) {?>
					<a href="javascript:addRepose('rps<?php echo $idea->id; ?>')" style="font-weight: bolder;font-style:italic"><?=JText::_("add Response")?></a> 
				<?php }?>
				
					</div>
				<?php 
				} ?>			
	            </div> 
            </div>   
            <?
			}
			?>                    
            <div class="comments">
            <?
            	$idea_comment = Idea::getComments($idea->id);
            ?>             
            	<div style="float:left;">
            	<font class='sum-comments' id='comment_count'><?=$idea_comment?></font>
            	<a href="index.php?option=com_foobla_suggestions&controller=comment&idea_id=<?=$idea->id?>"> comment(s)</a>
            	</div>
            	<div style="float:right;">
            <?
            	if (isset($content['overflow']) && JRequest::getString('controller')!='comment') {
            ?>
            	<a href="index.php?option=com_foobla_suggestions&controller=comment&idea_id=<?=$idea->id?>">Read more</a>
            	
            <?	
            	}
            ?>
            	</div>
            </div>
            <div class="box-action" style="<? echo ($can_response)?"":'height:2px;';?>">
	            <div class="column">
	                <div class="box-changeaction">
	                <a id="frm_Edit_<?=$idea->id?>" href="index.php?option=com_foobla_suggestions&controller=idea&task=editIdea&id=<?=$idea->id?>&format=raw" rel="{handler: 'iframe',size: {x: 418, y: 300}}"></a> 
	                <?php 
	                    $edit = '';
	                    if (
	                        ($this->output->permission->edit_idea_a == 1) || 
	                        (($this->output->permission->edit_idea_o == 1) && ($this->output->user->id == $idea->user_id))) 
	                    {
	                        $edit = '<option value="onedit(\''.$idea->id.'\')">'.JText::_("Edit").'</option>';//  onClick="onedit(<?php echo $idea->id; 
	                    }
	                ?>
	                <?php 
	                    $delete = '';
	                    if (
	                        ($this->output->permission->delete_idea_a == 1) || 
	                        (($this->output->permission->delete_idea_o == 1) && ($this->output->user->id == $idea->user_id))
	                    ) 
	                    {
	                        $delete = '<option value="ondel(\''.$idea->id.'\')">'.JText::_("Delete").'</option>';
	                    }
	                ?>
	                <? 
	                    if( $edit!='' || $delete != '')
	                    {
	                ?>	
	                    <input type="button" value="Action" onClick="eval(document.getElementById('sl_<?=$idea->id?>').value)" />
	                    <select id="sl_<?=$idea->id?>">
	                        <?=$edit?>
	                        <?=$delete?>
	                    </select>
	                <?
	                    }
	                ?>    
	                </div>
	          
	                <div class="box-changeastatus">
	                <?
	                if (
	                    ($this->output->permission->change_status_a == 1) || 
	                    (($this->output->permission->change_status_o == 1) && ($this->output->user->id == $idea->user_id))
	                ) 
	                {
	                ?>
	                    Change status
	                    <select onchange="updateIdeaStatus(<?=$idea->id?>,this.value)" >
	                        <option selected="selected" value="0">Start / Set Close</option>
	                        <?
	                        foreach ($this->status as $parent ) {
	                            if($parent->parent_id==-1)
	                            {
	                                echo '<optgroup label="'.$parent->title.'">';
	                                foreach($this->status as $child)
	                                {		
	                                    if($child->parent_id != $parent->id) continue;																										
	                                    if ($child->id == $idea->status_id) {
	                                        echo '<option value="'.$child->id.'"  selected="selected" class="status_"'.str_replace(" ", "_",strtolower($idea->status)).'">' . $child->title . '</option>';									
	                                    }		
	                                    else
	                                    {
	                                        echo '<option value="'.$child->id.'">' . $child->title . '</option>';
	                                    }		
	                                }						
	                                echo '</optgroup>';
	                            }													
	                        }
	                        ?>
	                    </select>
	                <?
	                }
	                ?>   
	                </div>
	            </div>            
	            <div style="clear:both;"></div>
	        </div> 
        </div>               
              
	<?php 
		} 
	}
	else 
	{
	?>
		<div style="margin:0px 1px 0px 1px;text-align:center;border:1px dotted #999999;background:#ffffcc;"><?echo JText::_("No idea found!");?></div>
	<?
	}
	?>	
	</div>
<input type="hidden" id="count_search_idea" value="<? echo $this->total;?>">
</div>
<div>
	<div class="pagination"><?echo $this->pagination;?></div>
</div>

<input type="hidden" name="totalRecord" id="totalRecord" value="<?php echo count($this->ideas);?>" />
