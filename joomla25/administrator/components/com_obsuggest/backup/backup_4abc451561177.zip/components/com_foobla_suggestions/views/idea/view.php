<?
/**
 * @package: foobla Suggestions forum.
 * @created: July 2009.
  * @copyright: Copyright (C) 2008-2009 foobla.com. All right reserved.
 * @author: Cuong Pham - foobla Team member.
 * @license: GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
defined("_JEXEC") or die("not Access");
jimport('joomla.application.component.view');

class ViewIdea extends JView {
	function __construct() {
		parent::__construct();
	}
	
	function display($tmp = null) {
		$ideas = $this->get('Ideas');
		$model = &$this->getModel('idea');
		$forum_id = $model->getForumId();
		$status = $this->get('Status');
		$output = $this->get('Output');
		$idea_title = JRequest::getString("idea_title");
		$this->assignRef("idea_title", $idea_title);
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);
		
		$search = 0;
		$this->assignRef('search',$search);
		parent::display($tmp);
	}
	
	function dispIdeaWithUserid($tmp = null){ 
		$model = &$this->getModel('idea');
		$ideas = $model->getIdeaWithUserid();
		$output = $this->get('Output');
		$status = $this->get('Status');
		
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);
		$this->assignRef('status',$status);
		$this->assignRef('ideas',$ideas);		
		parent::display($tmp);
	}
	
	function dispIdea($tmp = null) {
		$idea = $this->get('Idea');
		$idea->content = str_replace("\"",'\\"',$idea->content);
		$idea->content = str_replace(chr(13),'\n',$idea->content);
		$idea->title = str_replace("\"",'\\"',$idea->title);
		$status = $this->get('Status');
		
		$this->assignRef('status',$status);
		$this->assignRef('idea',$idea);		
		parent::display($tmp);
	}
	
	
	function dispIdeaWithStatus($tmp = null) {
		$model = &$this->getModel('idea');
		$output = $this->get('Output');
		$forum_id = $model->getForumId();
		$ideas = $model->getListIdea();
		$status = $this->get('Status');
		
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);	
		parent::display($tmp);
	}
	
	function dispTopIdea($tmp = null)
	{		
		$model = &$this->getModel('idea');
		$output = $this->get('Output');
		$forum_id = $model->getForumId();
		$ideas = $model->getTopIdeas();
		$status = $this->get('Status');
		$total = $model -> topIdeaCount();
		$cur_page = JRequest::getVar("page", 1);
		if($total>10)
		{
			$pagination = new Paging($total, $cur_page, 10, "index.php?option=com_foobla_suggestions&controller=idea&task=topIdea&forum=".$forum_id."&format=raw");
			$pagination = $pagination->getPagination();
		}
		else 	
			$pagination = "";
		$this->assignRef('total',$total);
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);	
		$this->assignRef('pagination', $pagination);
		parent::display($tmp);
	}
	
	function dispHotIdea($tmp = null){
		$model = &$this->getModel('idea');
		$output = $this->get('Output');
		$forum_id = $model->getForumId();
		$ideas = $model->getHotIdeas();
		$status = $this->get('Status');
		
		$total = $model->getHotIdeaCount();
		
		$cur_page = JRequest::getInt("page", 1);
		
		if($total>10)
		{
			$pagination = new Paging($total, $cur_page, 10, "index.php?option=com_foobla_suggestions&controller=idea&task=hotIdea&forum=".$forum_id."&format=raw");
			$pagination = $pagination->getPagination();
		}
		else 
		{
			$pagination = "";
		}
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);	
		$this->assignRef("pagination", $pagination);
		parent::display($tmp);
	}
	
	function dispIdeaById($tmp = null){
		$model = &$this->getModel('idea');
		$output = $this->get('Output');
		$forum_id = $model->getForumId();
		$ideas = $model->getIdeaById();
		$status = $this->get('Status');
		
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);	
		parent::display($tmp);
	}
	
	function dispNewIdea($tmp = null){
		$model = &$this->getModel('idea');
		$output = $this->get('Output');
		$forum_id = $model->getForumId();
		$ideas = $model->getNewIdeas();
		$status = $this->get('Status');
		
		$total = $model->getNewIdeasCount();
		
		$cur_page = JRequest::getInt("page", 1);
		
		if($total>10)
		{
			$pagination = new Paging($total, $cur_page, 10, "index.php?option=com_foobla_suggestions&controller=idea&task=newIdea&forum=".$forum_id."&format=raw");
			$pagination = $pagination->getPagination();
		}else $pagination = "";
		$this->assignRef('ideas',$ideas);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('status',$status);
		$this->assignRef('output',$output);	
		$search = 0;
		$this->assignRef('search',$search);	
		$this->assignRef("pagination", $pagination);
		parent::display($tmp);
	}
	
	function dispSearch($tmp = null) {	
		$model = &$this->getModel('idea');
		$forum_id = $model->getForumId();
		$ideas = $this->get('Ideas');
		$status = $this->get('Status');
		$output = $this->get('Output');
		
		$this->assignRef('total', $model->total);
		$this->assignRef('ideas',$ideas);
		$this->assignRef('status',$status);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('output',$output);
		$search = 1;
		$page = JRequest::getInt("page", 1);
		
		if($model->total>10)
		{
			$pageIdea = new Paging($model->total, $page, 10, "index.php?option=com_foobla_suggestions&controller=idea&task=search&forum=".$forum_id."&key=" .JRequest::getVar("key")."&format=raw");
			$pageIdea = $pageIdea->getPagination();
		}
		else $pageIdea = "";
		$this->assignRef("pagination", $pageIdea);
		
		$this->assignRef("keyword", JRequest::getString("key"));
		$this->assignRef('search',$search);
		parent::display($tmp);
	}	
	function getUser($_user_id) {
		$model = &$this->getModel('idea');
		return $model->getUser($_user_id);
	}
	public function getUserVoteIdea($_idea_id) {
		$model = $this->getModel('idea');
		$rs = $model->getUserVoteIdea($_idea_id);
		if ($rs != NULL)
			return $rs->vote;
		else return 0;
	}
	
	function dispAllIdeas($tmp = null) {	
		$model = &$this->getModel('idea');
		
		$ideas = $this->get('AllIdeas');
		$status = $this->get('Status');
		$output = $this->get('Output');
		
		//$this->assignRef('total', $model->total);
		$this->assignRef('ideas',$ideas);
		$this->assignRef('status',$status);
		$this->assignRef('forum_id',$forum_id);
		$this->assignRef('output',$output);
		$search = 0;
		
		$this->assignRef('search',$search);
		parent::display($tmp);
	}	
	function displayCountIdeas()
	{
		$model = &$this->getModel("idea");
		$count_ideas = $model->countIdeas(JRequest::getVar("user_id"));
		$count_comments = $model->countComments(JRequest::getVar("user_id"));
		
		$this->assignRef("count_ideas", $count_ideas);
		$this->assignRef("count_comments", $count_comments);
		parent::display("count_ideas");
	}
	
}
?>