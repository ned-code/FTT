<?php
defined('_JEXEC') or die;

?>
<footer>
    <p>© Company 2013</p>
</footer>