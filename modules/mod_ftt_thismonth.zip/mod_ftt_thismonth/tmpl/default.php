<?php
defined('_JEXEC') or die;

?>
