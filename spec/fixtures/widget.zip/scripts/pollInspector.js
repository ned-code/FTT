//start of the widget
widget.onLoad = function() {
	//load the current poll
	loadPoll(displayPoll);
}

//******* save the poll ***********
function savePoll() {
	var c;
	
	//update the question
	c = document.getElementById('i_question');
	if(c.value == '') {
		alert('Please enter a question.')
		c.focus();
		return;
	}
	poll.question = c.value;
	
	//go through all option
	for(i=0; i<poll.options.length; i++) {
		//c = document.getElementById('option_'+i);
		c = document.getElementsByName('option_value')[i];
		if(c.value == '') {
			alert('Please enter a choice.')
			c.focus();
			return;	
		}
		poll.options[i].text = c.value;
	}
	
	//update has_hother
	c = document.getElementById('other');
	if(c.checked)
		poll.has_other = true;
	else
		poll.has_other = false;
		
	//update show_result
	c = document.getElementById('show_result');
	if(c.checked)
		poll.show_result = true;
	else
		poll.show_result = false;
	
    savePollToPref();
}

//***************************************

/************************************* POLL SECTION *************************************/
//display the poll (or error)
function displayPoll() {
	var c = document.getElementById('container');
	
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the poll (' + error + ').';
		return;
	}
	
	if(!poll) { //if no poll, create an empty one
		poll = {
			question: '',
			options:[],
			has_other: false
		}
	}
	
	var data = '';
	
	data += '<div id="question">Enter your question:<br><input class="question" type="text" id="i_question" value="' + poll.question + '" /></div><div id="options"><h1>Options:</h1><div id="options_list">';
	
	for(i=0; i<poll.options.length;i++) {
		data += '<div class="option" id="option_line_' + i + '"><a class="delete" href="javascript:deleteOption(' + i + ');" alt="Delete choice"><img src="images/delete.png" alt="delete" /></a><input class="option" type="text" name="option_value" id="option_' + i + '" value="' + poll.options[i].text + '" /></div>';
	}
	
	data += '</div><a href="javascript:addOption();">Add a new option</a>';
	data += '<br><br>';
	
	data += '<input type="checkbox" id="other" ';
	if(poll.has_other)
		data += 'checked="checked"';
	data += '/>Has choice "Other"';
	
	data += '<br><input type="checkbox" id="show_result" ';
	if(poll.show_result)
		data += 'checked="checked"';
	data += '/>Allow users to show results';

	data += '</div><div id="buttons">';
	data += '<a class="button" href="javascript:savePoll()">Save</a>';
	data += '</div>';
	
	c.innerHTML = data;
}

//Add a new option to the list
function addOption() {
	//add to Poll object
	poll.options.push({text: 'new'});
	
	//add to screen
	var parent = document.getElementById('options_list');
	var d = document.createElement('div');
	var i = poll.options.length-1;
	//d.innerHTML = '<div class="option" id="option_line_' + i + '"><a class="delete" href="javascript:deleteOption(' + i + ');" alt="Delete choice">[X]</a><input class="option" type="text" name="option_value" id="option_' + i + '" value="' + poll.options[i].text + '" /></div>';
	d.className = 'option';
	d.id = 'option_line_' + i;
	d.innerHTML = '<a class="delete" href="javascript:deleteOption(' + i + ');" alt="Delete choice"><img src="images/delete.png" alt="delete" /></a><input class="option" type="text" name="option_value" id="option_' + i + '" value="' + poll.options[i].text + '" />';
	parent.appendChild(d);
}

//Delete an option
function deleteOption(index) {
	if(!confirm('Are you sure you want to remove this option?'))
		return;
		
	//delete from Poll object
	poll.options.pop(index);
	
	//delete from screen
	var parent = document.getElementById('options_list');
	var element = document.getElementById('option_line_' + index);
	parent.removeChild(element);
}

/************************************* STYLE / TEMPLATES SECTION *************************************/

//display the style (or error)
function displayStyle() {
	var c = document.getElementById('container');
	
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the poll (' + error + ').';
		return;
	}
	
	var data = '';
	
	data += 'Templates:<br><br>';
	
	for(i=0; i<templates.length; i++) {
		data += '<div id="template_';
		data += templates[i].id;
		data += '" class="template_sample';
		if(templates[i].id == poll.current_template)
			data += ' template_selected';
		data += '" style="';
		data += templates[i].preview;
		data += '" onclick="javascript:setTemplate(';
		data += i;
		data += ');">'
		data += templates[i].name;
		data += '</div>';
	}
	data += '<div class="clear"></div><br>';
	
	//***************** customization zone
	if(poll.current_template != -1)
		data += '<a href="javascript:showCustomTemplate();">Customize template</a>';
	
	data += '<div id="custom_zone"';
	if(poll.current_template != -1)
		data += ' style="display:none;"';
	data += '><textarea id="template_custom">';
	data += poll.style;
	data += '</textarea><br><a class="button" href="javascript:saveCustomTemplate();">Save</a></div>';
	
	document.getElementById('container').innerHTML = data;

	c.innerHTML = data;
}

function showCustomTemplate() {
	//unselecte previous template
	if(poll.current_template != -1)
		document.getElementById('template_' + poll.current_template).className = 'template_sample';
	poll.current_template = -1;
	document.getElementById('custom_zone').style.display = '';
}

function setTemplate(index) {
	//unselecte previous template
	if(poll.current_template != -1)
		document.getElementById('template_' + poll.current_template).className = 'template_sample';
	//get id
	poll.current_template = templates[index].id;
	//select current template
	document.getElementById('template_' + poll.current_template).className = 'template_sample template_selected';
	//hide custom
	document.getElementById('custom_zone').style.display = 'none';
	//set the style
	document.getElementById('template_custom').value = templates[index].style;
	//save the template
	saveCustomTemplate();
}

function saveCustomTemplate() {
	poll.style = document.getElementById('template_custom').value;
	savePollToPref();
}

/************************************* ANALYSE SECTION *************************************/
//display the analyse (or error)
function displayAnalyse() {
	var c = document.getElementById('container');
	
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the poll (' + error + ').';
		return;
	}
	
	widget.datastore.getExtended('vote', displayAnalyseCallback);
}

function displayAnalyseCallback(votes, error) {
	var c = document.getElementById('container');
		
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the votes (' + error + ').';
		return;
	}
	if(!poll) {
		c.innerHTML = 'No poll is loaded.';
		return;
	}
	
	//build output
	var data = '<div id="container_analyse"><table class="analyse"><tr><th>email</th><th>date</th><th>Choice</th><th>Other</th></tr>';
	
	for(i=0; i<votes.length; i++) {
		data += '<tr><td>';
		data += votes[i].email;
		data += '</td><td>';
		data += votes[i].updated_at;
		data += '</td><td>';
		var vote = json_to_object(votes[i].value);
		data += vote.choice;
		data += '</td><td>';
		data += vote.other;
		data += '</td></tr>'
	}
	data += '</table></div>';
	
	c.innerHTML = data;
}

/************************************* END (Due date) *************************************/

//display the end tab
function displayEnd() {
	var c = document.getElementById('container');
	
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the poll (' + error + ').';
		return;
	}

	var data = 'The poll is currently: ';
	if(poll.is_open)
		data += '<span style="color:green;">open</span>';
	else
		data += '<span style="color:red;">close</span>';
	
	data += '<br><br><input type="button" value="';
	if(poll.is_open)
		data += 'Close poll';
	else
		data += 'Open poll';
	data +='" onclick="javascript:invertPollCloseStatus()" />'
	
	data += '<br><br><input type="checkbox" name="cb_end_date" id="cb_end_date" onchange="javascript:validateEndDateChoice();"';
	if(poll.end_date)
		data += ' checked="checked"';
	data += '"/>End at : ';
	data += '<input type="text" id="end_date" style="width: 100px" onchange="javascript:validateEndDate();"';
	if(poll.end_date)
		data += ' value="' + poll.end_date + '"'
	data +='/> (yyyy/mm/dd)'
	
	c.innerHTML = data;
}

//validate the checkbox (on/off) of the end date
function validateEndDateChoice() {
	var c = document.getElementById('cb_end_date');
	if(c.checked) { //checkbox on, validate the date
		validateEndDate();
	}
	else { //checkbox off, cancel the date
		poll.end_date = null;
		savePollToPref(); //save poll
		displayEnd(); //redisplay panel
	}
}

//validate the end date
function validateEndDate() {
	var c = document.getElementById('cb_end_date');
	var i = document.getElementById('end_date');
	if(isDate(i.value, 'yyyy/MM/dd')) {
		c.checked = true;
		poll.end_date = i.value;
		poll.is_open = !isPollEndDatePassed();
		savePollToPref(); //save poll
		displayEnd(); //redisplay panel
	}
	else {
		if(i.value != '') {
			c.checked = false;
			alert("Date format is not valid (yyyy/mm/dd).");
		}
		i.focus();
	}
}


//open or close the poll depending on it current status
function invertPollCloseStatus() {
	poll.is_open = !poll.is_open; //invert the status
	poll.end_date = null; //cancel end date
	savePollToPref(); //save poll
	displayEnd(); //redisplay panel
}