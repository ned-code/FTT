var localizedStrings = new Array();
localizedStrings['key1'] = 'value 1';
localizedStrings['key2'] = 'value 2';
localizedStrings['key3'] = 'value 3';