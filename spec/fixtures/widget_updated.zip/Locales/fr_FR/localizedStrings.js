var localizedStrings = new Array();
localizedStrings['key1'] = 'valeur 1';
localizedStrings['key2'] = 'valeur 2';
localizedStrings['key3'] = 'valeur 3';