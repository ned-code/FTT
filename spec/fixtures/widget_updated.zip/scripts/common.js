/*
JSON format
the full poll is stored as a json object in the preference

poll = {
	question: 'xxx',
	options:[{
		text: 'this is question one'
		}],
	has_other: false,
	show_result: true,
	current_template = 1,
	style: '',
	is_open: true,
	end_date: null
	}

a vote is also stored as a json object into the datastore

vote = {
	choice: 1,
	other: ''
}
*/

var poll;
var error;
var afterLoadCallback;

//******* saving of the poll ***********
function savePollToPref() {
	widget.preferences.setValue('poll',object_to_json(poll));
}

//******* loading of the poll ***********
function loadPoll(callback) {
	afterLoadCallback = callback;
	pollValue = widget.preferences.getValue('poll', null);
  loadPollCallback.apply(this, [pollValue]);
}
function loadPollCallback(msg,error) {
	if(error != null) {
		error = error;
		return;
	}
	if(msg == null || msg == '')
		/*poll = {
			question: '',
			options:[],
			has_other: false,
			current_template : 1,
			style: templates[0].style
		}*/
		poll = {
			question: 'What is your favorite color?',
			options: [
				{text: 'Red'},
				{text: 'Green'},
				{text: 'Blue'}
			],
			has_other: true,
			show_result: true,
			current_template: 1,
			style: templates[0].style,
			is_open: true,
			end_date: null
		};
	else
		poll = json_to_object(msg);
	
	afterLoadCallback();
}

//******* verify validity of the poll (based on the date) ***********
function isPollEndDatePassed() {
	if(!poll.end_date)
		return false;

	if(compareDates(poll.end_date,'yyyy/MM/dd',formatDate(new Date(), 'yyyy/MM/dd'),'yyyy/MM/dd') == 0)
		return true;
	
	return false;
}