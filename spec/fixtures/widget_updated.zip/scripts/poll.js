var userVote = null;
var allVotes = null;

//start of the widget
widget.onLoad = function() {	
	//load the current poll (and after load user vote - if he has already voted)
	loadPoll(loadUserVote);
}

widget.onPreferencesChange = function() {
  loadPoll(loadUserVote);
}

//******* loading of the user vote ***********
function loadUserVote() {
	widget.datastore.getForCurrentUser('vote', loadUserVoteCallback);
}
function loadUserVoteCallback(msg,error) {
	if(error != null) {
		userVote = null;
		return;
	}
	
	userVote = json_to_object(msg);
	
	displayPoll();
}
//***************************************

//display the poll (or error)
function displayPoll() {
	allVotes = null;
	var c = document.getElementById('container');
	
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the poll (' + error + ').';
		return;
	}
	if(!poll || poll.question == '') {
		c.innerHTML = 'No poll is defined yet.<br>Use the inspector to build one.';
		return;
	}
	
	var data = '';
	
	//check if poll is still open
	var is_open = !isPollEndDatePassed();
	if(poll.is_open && is_open != poll.is_open) {
		poll.is_open = is_open;
		savePollToPref(); //save poll
	}
	
	if(!poll.is_open) {
		data += '<h1 class="msg">This poll is now closed.</h1>';
		c.innerHTML = data;
		setStyle(); //set the style of the poll
		return;
	}
	
	data += '<div id="question">' + poll.question + '</div><div id="options">';
	
	for(i=0; i<poll.options.length;i++) {
		data += '<div class="option"><input type="radio" id="option_' + i + '" name="r_options" value="' + i + '"';
		
		if(userVote != null && userVote.choice == i)
			data += 'checked="checked"';
		
		data += ' />' + poll.options[i].text + '</div>';
	}
	if(poll.has_other) {
		data += '<div class="option"><input type="radio" id="option_other" name="r_options" value="-1"';
		
		if(userVote != null && userVote.choice == -1)
			data += 'checked="checked"';
		data += ' />Other:<br><textarea id="other">';
		if(userVote != null && userVote.choice == -1)
			data += userVote.other;
		data += '</textarea></div>';
	}
	data += '</div><div id="buttons">';
	if(poll.show_result) {
		data += '<a class="smallButton" href="javascript:displayResults(false)">View results</a>';
	}
	data += '<a class="button" href="javascript:submitPoll()">Vote</a>';
	data += '</div>';
	
	c.innerHTML = data;
	setStyle(); //set the style of the poll
}

//post answers of the user
function submitPoll() {
	//check that the user has made a choice
	var list = document.getElementsByName('r_options');
	var value = -2;
	var other = ''; //other text
	
	for(i=0; i<list.length; i++) {
		if(list[i].checked) {
			value = list[i].value;
			break;
		}
	}
	
	if(value == -2) {
		alert('Please make a choice.');
		return;
	}
	
	if(value == -1) { //other text
		var o = document.getElementById('other');
		if(o) other = o.value;
	}
	
	saveVote(value, other); //save the vote
}

//******* save the vote ***********
function saveVote(choice, other) {
	var vote = {
		choice: choice,
		other: other
	}
	
	userVote = vote;
	
	//show visual indicator that we are saving
	var v = document.getElementById('buttons');
	v.innerHTML = 'Saving...';
	
	widget.datastore.set('vote',object_to_json(vote),false,saveVoteCallback);
}
function saveVoteCallback(msg,error) {	
	displayResults(true);
}
//**********************************

//*******display results for the user
var resultsHasVote = false;

function displayResults(hasVote) {
	resultsHasVote = hasVote;
	
	if(!poll.show_result) {
		if(hasVote) {
			var c = document.getElementById('container');
			data = '<h1 class="msg">Thank you for voting</h1>';
			data += '<a class="smallButton" href="javascript:displayPoll()">Return to Poll</a>';
			c.innerHTML = data;
			setStyle(); //set the style of the poll
		}
		return;
	}
	
	widget.datastore.get('vote', displayResultsCallback);
}

function displayResultsCallback(votes, error) {
	allVotes = votes;
	var c = document.getElementById('container');
		
	if(error) {
		c.innerHTML = 'Sorry, an error occured while loading the votes (' + error + ').';
		return;
	}
	if(!poll) {
		c.innerHTML = 'No poll is loaded.';
		return;
	}
	
	//*** start compute synthesis
	var synthesis = new Array();
	for(i=0; i<votes.length; i++) {
		var vote = json_to_object(votes[i]);
		if(typeof(synthesis[vote.choice]) == 'undefined') {
			synthesis[vote.choice] = 1;
		}
		else {
			++synthesis[vote.choice];
		}
	}
	//*** end compute synthesis
	
	var data = '';
	
	if(resultsHasVote)
	 	data += '<h1 class="msg">Thank you for voting</h1>';

	for(i=0; i<poll.options.length;i++) {
		var vote = 0;
		if(typeof(synthesis[i]) != 'undefined') vote = synthesis[i];
		
		var percentage = 0;
		if(votes.length > 0)
			percentage = Math.round(vote * 100 / votes.length);
		
		data += '<div class="result">' + poll.options[i].text + ' ' + percentage + '% (' + vote + ' votes)';
		data += '<div class="progressBar"><div class="progressIndicator" style="width:' + percentage + '%"></div></div>';
		data += '</div>';
	}
	//other
	if(poll.has_other) {
		var vote = 0;
		if(typeof(synthesis[-1]) != 'undefined') vote = synthesis[-1];
		var percentage = 0;
		if(votes.length > 0)
			percentage = Math.round(vote * 100 / votes.length);
		data += '<div class="result">Other ' + percentage + '% (' + vote + ' votes)';
		data += '<div class="progressBar"><div class="progressIndicator" style="width:' + percentage + '%"></div></div>';
		data += '</div>';
	}

	data += '</div>Total Votes: ' + votes.length;
	data += '<div id="buttons">';
	data += '<a class="smallButton" href="javascript:displayComments()" style="margin-right: 20px;">View Comments</a>';
	data += '<a class="smallButton" href="javascript:displayPoll()">Return to Poll</a>';
	data += '</div>';
	
	c.innerHTML = data;
	setStyle(); //set the style of the poll
}
//*************************************

//*******display comments
function displayComments() {
	var c = document.getElementById('container');
	var data = '';
	var menu = '';
		
	if(allVotes == null) {
		c.innerHTML = 'Sorry, votes are not loaded';
		return;
	}
	if(!poll) {
		c.innerHTML = 'No poll is loaded.';
		return;
	}
	
	menu += '<a class="smallButton" href="javascript:displayResults()" style="margin-right: 20px;">Return to results</a>';
	menu += '<a class="smallButton" href="javascript:displayPoll()">Return to Poll</a>';
	
	data += menu;
	data += '<div id="comments">';
	var count = 1;
	for(i=0; i<allVotes.length; i++) {
		var vote = json_to_object(allVotes[i]);
		if(vote.other != '') {
			data += '<div class="comment">';
			data += count++;
			data += '. ';
			data += vote.other;
			data += '</div>';
		}
	}
	data += menu;
	data += '</div>';
	
	c.innerHTML = data;
	
	c = document.getElementById('comments');
	
	setStyle(); //set the style of the poll
}

//*************************************
//apply the style of the poll
function setStyle() {
	//remove previous style if exists
	var cs = document.getElementById('custom_style');
	if(cs)
		document.getElementsByTagName('head')[0].removeChild(cs);
		cs = document.getElementById('custom_style');
		
	//create the new style
	var styleNode = document.createElement('style');
	styleNode.type = "text/css";
	styleNode.id = 'custom_style';
	
	/*if(!!(window.attachEvent && !window.opera)) {
		styleNode.styleSheet.cssText = 'span { color: rgb(255, 0, 0); }';
	} else {
		var styleText = document.createTextNode('span { color: rgb(255, 0, 0); } ');
	    styleNode.appendChild(styleText);
	}*/
	var styleText = document.createTextNode(poll.style);
    styleNode.appendChild(styleText);

	//var c = document.getElementById('container');
	//c.appendChild(styleNode);
	document.getElementsByTagName('head')[0].appendChild(styleNode);
}
