var templates = Array();

/************************************* TEMPLATE 'default' *************************************/
templates.push({
		id: 1,
		name: 'default',
		preview: 'background-color:#E3E3E3;color:black;',
		style: '#container {\n\
background-color: #E3E3E3;\n\
border: solid 1px #999999;\n\
}\n\
\n\
#question {\n\
font-weight: bold;\n\
font-size: 1.2em;\n\
margin-bottom: 15px;\n\
}\n\
\n\
div.option {\n\
margin-bottom: 10px\n\
}\n\
\n\
.smallButton {\n\
color: #999999;\n\
font-size: 0.8em;\n\
}\n\
\n\
.button {\n\
font-weight: bold;\n\
background-color: #aec7dc;\n\
border: solid 2px #6ca0cb;\n\
padding: 2px 10px;\n\
color: black;\n\
text-decoration: none;\n\
margin-left: 50px;\n\
}\n\
\n\
div.result {\n\
margin-bottom: 25px;\n\
}\n\
\n\
div.progressBar {\n\
width: 100%;\n\
height: 20px;\n\
background-color: #afb1b9;\n\
margin-top: 10px;\n\
}\n\
div.progressIndicator {\n\
background-color: #7ec07e;\n\
border: solid 2px #148e14;\n\
height: 16px;\n\
}'
	});

/************************************* TEMPLATE 'black mamba' *************************************/
templates.push({
		id: 2,
		name: 'black',
		preview: 'background-color:black;color:white;',
		style: '#container {\n\
background-color: black;\n\
border: solid 1px black;\n\
color: white;\n\
}\n\
\n\
#question {\n\
font-weight: bold;\n\
font-size: 1.2em;\n\
margin-bottom: 15px;\n\
}\n\
\n\
div.option {\n\
margin-bottom: 10px\n\
}\n\
\n\
.smallButton {\n\
color: #999999;\n\
font-size: 0.8em;\n\
}\n\
\n\
.button {\n\
font-weight: bold;\n\
background-color: #aec7dc;\n\
border: solid 2px #6ca0cb;\n\
padding: 2px 10px;\n\
color: black;\n\
text-decoration: none;\n\
margin-left: 50px;\n\
}\n\
\n\
div.result {\n\
margin-bottom: 25px;\n\
}\n\
\n\
div.progressBar {\n\
width: 100%;\n\
height: 20px;\n\
background-color: #afb1b9;\n\
margin-top: 10px;\n\
}\n\
div.progressIndicator {\n\
background-color: #7ec07e;\n\
border: solid 2px #148e14;\n\
height: 16px;\n\
}'
	});

/************************************* TEMPLATE 'red' *************************************/
templates.push({
		id: 3,
		name: 'red',
		preview: 'background-color:red;color:blue;',
		style: '#container {\n\
background-color: red;\n\
border: solid 1px black;\n\
color: blue;\n\
}\n\
\n\
#question {\n\
font-weight: bold;\n\
font-size: 1.2em;\n\
margin-bottom: 15px;\n\
}\n\
\n\
div.option {\n\
margin-bottom: 10px\n\
}\n\
\n\
.smallButton {\n\
color: #999999;\n\
font-size: 0.8em;\n\
}\n\
\n\
.button {\n\
font-weight: bold;\n\
background-color: #aec7dc;\n\
border: solid 2px #6ca0cb;\n\
padding: 2px 10px;\n\
color: black;\n\
text-decoration: none;\n\
margin-left: 50px;\n\
}\n\
\n\
div.result {\n\
margin-bottom: 25px;\n\
}\n\
\n\
div.progressBar {\n\
width: 100%;\n\
height: 20px;\n\
background-color: #afb1b9;\n\
margin-top: 10px;\n\
}\n\
div.progressIndicator {\n\
background-color: #7ec07e;\n\
border: solid 2px #148e14;\n\
height: 16px;\n\
}'
	});

/************************************* TEMPLATE 'green' *************************************/
templates.push({
		id: 4,
		name: 'green',
		preview: 'background-color:green;color:yellow;',
		style: '#container {\n\
background-color: green;\n\
border: solid 1px black;\n\
color: yellow;\n\
}\n\
\n\
#question {\n\
font-weight: bold;\n\
font-size: 1.2em;\n\
margin-bottom: 15px;\n\
}\n\
\n\
div.option {\n\
margin-bottom: 10px\n\
}\n\
\n\
.smallButton {\n\
color: #999999;\n\
font-size: 0.8em;\n\
}\n\
\n\
.button {\n\
font-weight: bold;\n\
background-color: #aec7dc;\n\
border: solid 2px #6ca0cb;\n\
padding: 2px 10px;\n\
color: black;\n\
text-decoration: none;\n\
margin-left: 50px;\n\
}\n\
\n\
div.result {\n\
margin-bottom: 25px;\n\
}\n\
\n\
div.progressBar {\n\
width: 100%;\n\
height: 20px;\n\
background-color: #afb1b9;\n\
margin-top: 10px;\n\
}\n\
div.progressIndicator {\n\
background-color: #7ec07e;\n\
border: solid 2px #148e14;\n\
height: 16px;\n\
}'
	});